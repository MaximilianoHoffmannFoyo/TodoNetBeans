/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoEjemplo;

/**
 *
 * @author gabriel
 */
public class ClaseEjemplo {
    //El metodo main es el que inicializa todas las clases
    public static void main(String[] args){
        //Código a ejecuntar
        //System es una clase
        System.out.println("Hola mundo");
    }
}
